"""
Plain-language sentence templates for PreFlight v2.0 Decision records.

Generates human-readable descriptions, questions, selectable options, and
safe defaults for every pipeline Decision kind.

Design Rules:
- Plain language only: no technical jargon (no "schema", "delimiter", "dtype",
  "coercion", "parse", "imputation", "winsorize", "cardinality", "heuristic",
  and no raw encoding names like "utf-8").
- All templates accept only structured fields (column names, counts, example values),
  never raw unvetted free text from internal diagnostic dumps.
"""

import codecs
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Optional

from preflight.decisions import Decision

# Banned jargon terms that must never appear in user-facing sentences or PDFs
BANNED_JARGON = [
    "imputation",
    "impute",
    "imputing",
    "winsorize",
    "winsorizing",
    "winsorization",
    "cardinality",
    "dtype",
    "dtypes",
    "coercion",
    "coerce",
    "coerced",
    "coercing",
    "heuristic",
    "heuristics",
    "parse",
    "parsing",
    "parser",
    "parsed",
    "schema",
    "schemas",
    "delimiter",
    "delimiters",
    "utf-8",
    "utf8",
    "latin-1",
    "windows-1252",
    "iso-8859-1",
    # Cleaning and engineering: plain equivalents are required
    "interaction",
    "interactions",
    "target encoding",
    "target-encode",
    "cross-fit",
    "one-hot",
    "ordinal",
    "tf-idf",
    "tfidf",
    "vif",
    "variance inflation",
    "multicollinearity",
    "kmeans",
    "k-means",
    "centroid",
    "outlier",
    "outliers",
    "median",
    "log1p",
    "z-score",
    "leakage",
]


def find_jargon_violations(text: str) -> list[str]:
    """
    Return every banned jargon term that appears in `text` (case-insensitive,
    whole-word match). Empty list means the text is plain language.

    Shared by the Plan PDF and the Report PDF so both documents are checked
    against the same banned-term list.
    """
    if not text:
        return []
    lower = text.lower()
    found: list[str] = []
    for term in BANNED_JARGON:
        pattern = r"(?<![a-z0-9])" + re.escape(term.lower()) + r"(?![a-z0-9])"
        if re.search(pattern, lower):
            found.append(term)
    return found


def assert_plain_language(text: str, context: str = "") -> None:
    """Raise ValueError naming the offending term(s) if `text` contains banned jargon."""
    violations = find_jargon_violations(text)
    if violations:
        where = f" in {context}" if context else ""
        raise ValueError(f"Banned jargon term(s) {violations} found{where}: {text!r}")


@dataclass(frozen=True)
class RenderedDecisionText:
    """Structured plain-language rendered text for a pipeline Decision."""
    summary: str
    question: Optional[str] = None
    options: list[str] = field(default_factory=list)
    recommended_default: Optional[str] = None
    explanation: Optional[str] = None


# ---------------------------------------------------------------------------
# Friendly Term Mappings (Plain Equivalents)
# ---------------------------------------------------------------------------

# Plain names for encoding families, keyed by codecs.lookup() names. Each family gets its own
# name so that rival encodings offered in a question never share a label.
_TEXT_FORMAT_FAMILIES: dict[str, tuple[str, ...]] = {
    "standard text format": ("utf-8", "utf-8-sig"),
    "basic text format": ("ascii",),
    "wide character text format": ("utf-16", "utf-16-le", "utf-16-be", "utf-32"),
    "Western European text format": ("cp1252", "iso8859-1", "iso8859-15"),
    "older Western European text format": ("cp437", "cp850", "cp858", "mac-roman"),
    "Central European text format": ("cp1250", "iso8859-2", "cp852", "mac-latin2"),
    "Baltic text format": ("cp1257", "cp775", "iso8859-4", "iso8859-13"),
    "Cyrillic text format": ("cp1251", "koi8-r", "koi8-u", "cp866", "cp855", "iso8859-5", "mac-cyrillic"),
    "Greek text format": ("cp1253", "iso8859-7", "mac-greek", "cp737", "cp869"),
    "Turkish text format": ("cp1254", "iso8859-9", "cp857", "mac-turkish"),
    "Hebrew text format": ("cp1255", "iso8859-8", "cp862"),
    "Arabic text format": ("cp1256", "iso8859-6", "cp864", "cp720"),
    "Vietnamese text format": ("cp1258",),
    "Thai text format": ("tis-620", "cp874", "iso8859-11"),
    "Japanese text format": ("cp932", "shift_jis", "euc_jp", "iso2022_jp", "shift_jis_2004", "euc_jis_2004"),
    "Simplified Chinese text format": ("gb2312", "gbk", "gb18030", "hz"),
    "Traditional Chinese text format": ("big5", "cp950", "big5hkscs"),
    "Korean text format": ("euc_kr", "cp949", "johab", "iso2022_kr"),
}
_TEXT_FORMAT_BY_CODEC = {c: name for name, codecs_ in _TEXT_FORMAT_FAMILIES.items() for c in codecs_}


def friendly_text_format(enc_name: Optional[str]) -> str:
    """Map character encoding identifiers to user-friendly plain descriptions."""
    if not enc_name:
        return "standard text format"
    raw = enc_name.strip()
    try:
        norm = codecs.lookup(raw).name
    except LookupError:
        norm = raw.lower()
    if norm in _TEXT_FORMAT_BY_CODEC:
        return _TEXT_FORMAT_BY_CODEC[norm]
    # Unknown to the table: name it, so it is never mistaken for the standard format.
    return f"regional text format ({raw})"


def friendly_separator_name(sep_char: Optional[str]) -> str:
    """Map delimiter characters to plain-language names."""
    if not sep_char:
        return "comma"
    if sep_char == ",":
        return "comma"
    if sep_char == ";":
        return "semicolon"
    if sep_char == "\t":
        return "tab"
    if sep_char == "|":
        return "pipe"
    if sep_char == " ":
        return "space"
    return "symbol"


def friendly_type_name(inferred_type: Optional[str]) -> str:
    """Map type keywords to non-jargon plain descriptions."""
    if not inferred_type:
        return "plain text"
    t = inferred_type.lower()
    if t in ("int", "integer"):
        return "whole numbers"
    if t in ("float", "numeric", "number"):
        return "decimal numbers"
    if t in ("bool", "boolean"):
        return "yes/no values"
    if t in ("datetime", "date", "timestamp"):
        return "dates and times"
    if t in ("categorical", "category"):
        return "categories"
    if t in ("text", "string"):
        return "plain text"
    if t == "id":
        return "identifiers"
    if t == "constant":
        return "constant values"
    return "plain text"


_PREP_ACTION_NAMES = {
    "drop_column": "Remove this column",
    "keep_column": "Keep this column",
    "remove_duplicates": "Remove the repeated rows",
    "keep_rows": "Keep all rows, including repeats",
    "clip_outliers": "Pull extreme values back into range",
    "keep_outliers": "Keep extreme values as they are",
    "keep_feature": "Keep this column as an input",
    "drop_leaky_feature": "Leave this column out",
    "convert_missing_markers": "Treat placeholder entries as blank",
    "coerce_numeric": "Read as numbers",
    "normalize_categories": "Tidy the text",
    "group_rare_categories": "Combine very uncommon values",
    "add_missing_indicator": "Add a blank-marker column",
    "fill_median": "Fill blanks with the middle value",
    "fill_mode": "Fill blanks with the most common value",
    "constant_fill": "Fill blanks with a label",
    "expand_datetime": "Split dates into parts",
    "ordinal_encode": "Turn categories into numbers",
    "one_hot_encode": "One yes/no column per category",
    "target_encode_cross_fit": "Use the typical outcome per category",
    "log1p_transform": "Compress the long tail",
    "standard_scale": "Rescale to a common scale",
    "create_interactions": "Create combined columns",
    "create_datetime_features": "Create extra date columns",
    "create_cluster_features": "Create group columns",
    "create_text_features": "Create text size columns",
    "drop_rows": "Set these rows aside",
    "note_class_imbalance": "Note only; nothing changes",
    "note_grouped_rows": "Note only; nothing changes",
}


def friendly_action_name(action: str) -> str:
    """Map raw code actions to human-friendly descriptions."""
    if not action:
        return "Preserve plain text"
    act = action.lower()
    if act in _PREP_ACTION_NAMES:
        return _PREP_ACTION_NAMES[act]
    if act == "keep_as_string":
        return "Keep original plain text"
    if act == "keep_as_constant":
        return "Keep constant value"
    if act == "keep_as_id":
        return "Keep identifier text"
    if act in ("keep_as_categorical", "cast_to_categorical"):
        return "Convert to categories"
    if act == "cast_to_int":
        return "Convert to whole numbers"
    if act == "cast_to_float":
        return "Convert to decimal numbers"
    if act == "cast_to_boolean":
        return "Convert to yes/no values"
    if act == "cast_to_datetime":
        return "Convert to dates and times"
    if act.startswith("use_encoding_"):
        return f"Use {friendly_text_format(act.replace('use_encoding_', ''))}"
    if act.startswith("separate_by_"):
        return f"Separate by {friendly_separator_name(act.replace('separate_by_', ''))}"
    if act.startswith("use_header_row_"):
        return f"Use row {int(act.replace('use_header_row_', '')) + 1} as column names"
    if act == "no_header":
        return "No title row in file"
    if act == "classification":
        return "Predict categories (classification)"
    if act == "regression":
        return "Predict numerical values (regression)"
    return act


def _format_examples(examples: Optional[Sequence[Any]], max_items: int = 3) -> str:
    """Format sample values safely without technical syntax."""
    if not examples:
        return ""
    clean = [str(x).strip() for x in examples if str(x).strip()]
    if not clean:
        return ""
    sample = clean[:max_items]
    return f" (examples: {', '.join(sample)})"


# ---------------------------------------------------------------------------
# Per-Kind Plain-Language Templates
# ---------------------------------------------------------------------------

def template_encoding(
    text_format_name: str,
    confidence: float = 1.0,
    has_bom: bool = False,
    needs_attention: bool = False,
) -> RenderedDecisionText:
    """Plain-language template for text format (encoding) decisions."""
    friendly = friendly_text_format(text_format_name)
    summary = f"Read the file using {friendly}."

    if needs_attention or confidence < 0.80:
        question = "Which text format should be used to read this file?"
        options = [
            f"Use {friendly} (recommended)",
            "Use Western European text format",
            "Use standard text format",
        ]
        recommended = f"Use {friendly} (recommended)"
        explanation = (
            f"The file text format was identified as {friendly} with moderate confidence. "
            "Confirm if special characters appear correctly."
        )
        return RenderedDecisionText(
            summary=summary,
            question=question,
            options=options,
            recommended_default=recommended,
            explanation=explanation,
        )

    return RenderedDecisionText(summary=summary)


def template_dialect(
    separator_char: str,
    confidence: float = 1.0,
    needs_attention: bool = False,
) -> RenderedDecisionText:
    """Plain-language template for column separator (dialect) decisions."""
    friendly = friendly_separator_name(separator_char)
    summary = f"Separate columns using {friendly} separators."

    if needs_attention or confidence < 0.80:
        question = "Which separator splits columns into fields?"
        options = [
            f"Separate columns by {friendly} (recommended)",
            "Separate columns by semicolon",
            "Separate columns by tab",
            "Separate columns by comma",
        ]
        recommended = f"Separate columns by {friendly} (recommended)"
        explanation = (
            f"Multiple candidate column separators were detected. "
            f"Using {friendly} provided the most consistent column structure."
        )
        return RenderedDecisionText(
            summary=summary,
            question=question,
            options=options,
            recommended_default=recommended,
            explanation=explanation,
        )

    return RenderedDecisionText(summary=summary)


def template_header(
    header_row_index: Optional[int],
    title_rows_count: int = 0,
    is_ragged: bool = False,
    needs_attention: bool = False,
) -> RenderedDecisionText:
    """Plain-language template for table header and boundary decisions."""
    if header_row_index is not None:
        row_num = header_row_index + 1
        if title_rows_count > 0:
            summary = (
                f"Skip {title_rows_count} title row(s) and use row {row_num} for column names."
            )
        else:
            summary = f"Use row {row_num} as column names."
    else:
        summary = "No column names row found; assign automatic column names."

    if needs_attention or is_ragged:
        question = "Which row contains the column names?"
        options = [
            "Use row 1 as column names",
            "No column names row in file",
            "Skip leading rows before reading column names",
        ]
        recommended = options[0] if header_row_index is not None else options[1]
        explanation = (
            "Table row lengths vary across the file or the header row was ambiguous."
        )
        return RenderedDecisionText(
            summary=summary,
            question=question,
            options=options,
            recommended_default=recommended,
            explanation=explanation,
        )

    return RenderedDecisionText(summary=summary)


def template_type(
    column_name: str,
    inferred_type: str,
    example_values: Optional[Sequence[Any]] = None,
) -> RenderedDecisionText:
    """Plain-language template for standard column type decisions."""
    friendly = friendly_type_name(inferred_type)
    eg_str = _format_examples(example_values)
    summary = f"Read column '{column_name}' as {friendly}{eg_str}."
    return RenderedDecisionText(summary=summary)


def template_missing_marker(
    column_name: str,
    marker_value: str,
    count: int = 1,
    needs_attention: bool = False,
) -> RenderedDecisionText:
    """Plain-language template for detected missing-value markers."""
    occ_str = f"{count} occurrence" if count == 1 else f"{count} occurrences"
    summary = f"Treat '{marker_value}' as missing data in column '{column_name}' ({occ_str})."

    if needs_attention:
        question = f"Should '{marker_value}' in column '{column_name}' be treated as missing data?"
        options = [
            f"Treat '{marker_value}' as missing data (recommended)",
            f"Keep '{marker_value}' as a valid value",
        ]
        recommended = options[0]
        explanation = (
            f"The value '{marker_value}' looks like a placeholder for missing information "
            f"rather than a regular measurement."
        )
        return RenderedDecisionText(
            summary=summary,
            question=question,
            options=options,
            recommended_default=recommended,
            explanation=explanation,
        )

    return RenderedDecisionText(summary=summary)


def template_abstention(
    column_name: str,
    reason_description: str = "",
    example_values: Optional[Sequence[Any]] = None,
) -> RenderedDecisionText:
    """Plain-language template for column type abstentions."""
    eg_str = _format_examples(example_values)
    summary = f"Keep column '{column_name}' as plain text to preserve original content{eg_str}."
    question = f"How should column '{column_name}' be interpreted?"
    options = [
        "Keep as plain text (safest)",
        "Convert to whole numbers",
        "Convert to decimal numbers",
        "Convert to categories",
    ]
    recommended = "Keep as plain text (safest)"
    explanation = (
        f"Column '{column_name}' has mixed formats or ambiguous values. "
        "Keeping plain text prevents accidental corruption or loss of detail."
    )
    return RenderedDecisionText(
        summary=summary,
        question=question,
        options=options,
        recommended_default=recommended,
        explanation=explanation,
    )


def template_anomaly(
    column_name: str,
    anomaly_description: str,
    example_values: Optional[Sequence[Any]] = None,
    needs_attention: bool = False,
) -> RenderedDecisionText:
    """Plain-language template for detected data anomalies."""
    eg_str = _format_examples(example_values)
    summary = f"Preserve values in column '{column_name}': {anomaly_description}{eg_str}."

    if needs_attention:
        question = f"How should unusual entries in column '{column_name}' be handled?"
        options = [
            "Preserve original values without modification (recommended)",
            "Standardize values into common format",
        ]
        recommended = options[0]
        explanation = f"Values in column '{column_name}' contain {anomaly_description}."
        return RenderedDecisionText(
            summary=summary,
            question=question,
            options=options,
            recommended_default=recommended,
            explanation=explanation,
        )

    return RenderedDecisionText(summary=summary)


def template_ambiguous_task(
    column_name: str,
    unique_count: int = 0,
    example_values: Optional[Sequence[Any]] = None,
) -> RenderedDecisionText:
    """Plain-language template for ambiguous modeling task inference."""
    eg_str = _format_examples(example_values)
    summary = (
        f"Select prediction objective for target column '{column_name}' "
        f"({unique_count} distinct values){eg_str}."
    )
    question = f"What type of prediction should be made for target '{column_name}'?"
    options = [
        "Predict categories (classification)",
        "Predict numerical values (regression)",
        "No prediction goal (data inspection only)",
    ]
    # If 2 to 10 unique values, default to classification; otherwise regression
    recommended = (
        "Predict categories (classification)"
        if 2 <= unique_count <= 10
        else "Predict numerical values (regression)"
    )
    explanation = (
        f"Target column '{column_name}' has {unique_count} distinct values. "
        "These could represent discrete groups or a numerical scale."
    )
    return RenderedDecisionText(
        summary=summary,
        question=question,
        options=options,
        recommended_default=recommended,
        explanation=explanation,
    )


# ---------------------------------------------------------------------------
# Cleaning and engineering Decisions
# ---------------------------------------------------------------------------

_SECTION_BY_KIND = {
    "convert_missing_markers": "fixing",
    "coerce_numeric": "fixing",
    "normalize_categories": "fixing",
    "group_rare_categories": "fixing",
    "clip_outliers": "fixing",
    "add_missing_indicator": "filling gaps",
    "fill_median": "filling gaps",
    "fill_mode": "filling gaps",
    "constant_fill": "filling gaps",
    "remove_duplicates": "removing",
    "drop_high_missingness": "removing",
    "drop_id": "removing",
    "drop_constant": "removing",
    "suspected_leakage": "removing",
    "feature_overlap": "removing",
    "missing_target_rows": "removing",
    "class_imbalance": "removing",
    "grouped_rows": "removing",
}


def section_for_decision(decision: Decision) -> str:
    """Plan PDF heading a Decision is listed under."""
    if decision.stage in ("reading", "ingest", "infer"):
        return "reading"
    if decision.stage == "clean":
        return _SECTION_BY_KIND.get(decision.kind, "fixing")
    if decision.stage == "engineer":
        return _SECTION_BY_KIND.get(decision.kind, "creating")
    return "reading"


_PREP_QUESTIONS = {
    "remove_duplicates": (
        "Remove the repeated rows?",
        "Many rows appear more than once. Removing them keeps one copy of each.",
    ),
    "drop_high_missingness": (
        "Remove this column?",
        "Most of its entries are blank, so it may not help.",
    ),
    "drop_id": (
        "Remove this identifier column?",
        "Each row has its own unique value here, so it labels rows rather than describing them.",
    ),
    "drop_constant": (
        "Remove this column?",
        "Every row has the same value, so it cannot help tell rows apart.",
    ),
    "clip_outliers": (
        "Pull extreme values back into range?",
        "A noticeable share of entries lie far from the rest. Pulling them back changes their values.",
    ),
    "suspected_leakage": (
        "Keep this column as an input, or leave it out?",
        "A column that matches the value to be predicted almost exactly can make results look better than they will be in real use.",
    ),
}


# Proposal wording that asks a question; once the Decision is resolved, the sentence
# must state the outcome instead (it may otherwise describe a step that never ran).
_PROPOSAL_QUESTION_TAILS = (
    ("? This is a large share, so please confirm.", ". This is a large share, and it was confirmed."),
    ("; please confirm.", "."),
)


def _resolved_prep_summary(decision: Decision, summary: str) -> str:
    """
    The sentence for a resolved cleaning Decision: what was actually done. A proposal
    declined (by a person or by defaults mode's safe default) is described as kept, and
    a confirmed proposal loses its "please confirm" question.
    """
    ev = decision.evidence or {}
    col = decision.columns[0] if decision.columns else None
    act = decision.action
    if decision.kind == "remove_duplicates" and act == "keep_rows":
        n = ev.get("duplicate_count")
        share = ev.get("impact_fraction")
        if isinstance(n, int) and isinstance(share, (int, float)):
            return (
                f"Keep all rows, including {n} repeated ones ({share:.1%} of the table); "
                "removing them would change a large share of the table."
            )
        return "Keep all rows, including repeated ones."
    if decision.kind == "clip_outliers" and act == "keep_outliers" and col:
        n = ev.get("outlier_count")
        share = ev.get("impact_fraction")
        if isinstance(n, int) and isinstance(share, (int, float)):
            word = "entry" if n == 1 else "entries"
            return (
                f"Leave the {n} extreme {word} in '{col}' ({share:.1%} of entries) as they are; "
                "pulling them back would change a large share of the column."
            )
        return f"Leave the extreme entries in '{col}' as they are."
    if act == "keep_column" and col:
        return f"Keep column '{col}'."
    for question_tail, statement_tail in _PROPOSAL_QUESTION_TAILS:
        if summary.endswith(question_tail):
            return summary[: -len(question_tail)] + statement_tail
    return summary


def template_prep_step(decision: Decision) -> RenderedDecisionText:
    """Plain-language text for cleaning and engineering Decisions."""
    summary = decision.plain_language or friendly_action_name(decision.action)
    if not decision.needs_attention:
        return RenderedDecisionText(summary=_resolved_prep_summary(decision, summary))
    title, why = _PREP_QUESTIONS.get(
        decision.kind, ("How should this be handled?", "This step changes your data noticeably.")
    )
    col = decision.columns[0] if decision.columns else None
    if col and decision.kind != "remove_duplicates":
        title = f"{title[:-1]} (column '{col}')?"
    options = [friendly_action_name(decision.action)]
    if decision.default != decision.action:
        options.append(friendly_action_name(decision.default))
    return RenderedDecisionText(
        summary=summary,
        question=title,
        options=options,
        recommended_default=friendly_action_name(decision.default),
        explanation=why,
    )


# ---------------------------------------------------------------------------
# Dispatcher for Arbitrary Decision Records
# ---------------------------------------------------------------------------

def render_decision_text(decision: Decision) -> RenderedDecisionText:
    """
    Render a Decision dataclass into verified plain-language text using structured fields.

    Extracts strictly structured fields from decision attributes and evidence,
    dispatching to the corresponding per-kind template.
    """
    kind = decision.kind.lower().replace("-", "_")
    col_name = decision.columns[0] if decision.columns else "table"
    ev = decision.evidence or {}

    if decision.stage in ("clean", "engineer"):
        return template_prep_step(decision)

    if kind in ("encoding", "text_format"):
        enc_name = (
            decision.action[len("use_encoding_"):]
            if decision.action.startswith("use_encoding_")
            else str(ev.get("encoding", decision.action))
        )
        return template_encoding(
            text_format_name=enc_name,
            confidence=decision.confidence,
            has_bom=bool(ev.get("has_bom", False)),
            needs_attention=decision.needs_attention,
        )

    if kind in ("dialect", "separator"):
        sep = (
            decision.action[len("separate_by_"):]
            if decision.action.startswith("separate_by_")
            else str(ev.get("delimiter", ","))
        )
        return template_dialect(
            separator_char=sep,
            confidence=decision.confidence,
            needs_attention=decision.needs_attention,
        )

    if kind in ("header", "table_boundary"):
        h_idx = ev.get("header_row_index")
        if decision.action.startswith("use_header_row_"):
            h_idx = int(decision.action[len("use_header_row_"):])
        t_count = len(ev.get("title_rows", [])) if decision.action.startswith("use_header_row_") else 0
        ragged = bool(ev.get("is_ragged", False))
        if decision.action == "no_header":
            return RenderedDecisionText(summary=template_header(None).summary)
        return template_header(
            header_row_index=h_idx if isinstance(h_idx, int) else 0,
            title_rows_count=t_count,
            is_ragged=ragged,
            needs_attention=decision.needs_attention,
        )

    if kind in ("type_abstain", "abstention", "abstain"):
        if decision.action != "keep_as_string" and not decision.needs_attention:
            return template_type(
                column_name=col_name,
                inferred_type=decision.action.replace("cast_to_", "").replace("keep_as_", ""),
                example_values=ev.get("sample_values") or [],
            )
        samples = ev.get("failed_samples") or ev.get("sample_values") or []
        reason = str(ev.get("unresolved_trap") or "uncertain format")
        return template_abstention(
            column_name=col_name,
            reason_description=reason,
            example_values=samples,
        )

    if kind in ("missing_marker", "missing_value"):
        marker = str(ev.get("marker", "?"))
        count = int(ev.get("count", 1))
        return template_missing_marker(
            column_name=col_name,
            marker_value=marker,
            count=count,
            needs_attention=decision.needs_attention,
        )

    if kind in ("anomaly", "data_anomaly"):
        desc = str(ev.get("anomaly_type") or "unusual pattern")
        samples = ev.get("sample_values", [])
        return template_anomaly(
            column_name=col_name,
            anomaly_description=desc,
            example_values=samples,
            needs_attention=decision.needs_attention,
        )

    if kind in ("ambiguous_task", "task_inference", "task"):
        u_count = int(ev.get("num_unique", 0))
        samples = ev.get("unique_samples", [])
        if decision.needs_attention:
            return template_ambiguous_task(
                column_name=col_name,
                unique_count=u_count,
                example_values=samples,
            )
        else:
            task_name = decision.action
            if task_name == "classification":
                summary = f"Predict categories for target column '{col_name}'."
            elif task_name == "regression":
                summary = f"Predict numerical values for target column '{col_name}'."
            else:
                summary = f"Target column '{col_name}' designated for inspection."
            return RenderedDecisionText(summary=summary)

    # Standard column type inference (kind == "type_inference" or "type")
    # Action typically is 'cast_to_int', 'keep_as_string', etc.
    t_name = decision.action.replace("cast_to_", "").replace("keep_as_", "")
    samples = ev.get("sample_values") or []
    return template_type(
        column_name=col_name,
        inferred_type=t_name,
        example_values=samples,
    )


# ---------------------------------------------------------------------------
# Question Phrasing (interaction layer)
# ---------------------------------------------------------------------------

def _pct(value: Any) -> str:
    try:
        return f"{round(float(value) * 100)}%"
    except (TypeError, ValueError):
        return "an unknown share"


def describe_type_scores(evidence: dict[str, Any]) -> str:
    """Plain-language summary of how well each reading fits a column's values."""
    scores = evidence.get("candidate_scores") or {}
    ranked = sorted(
        ((str(k).lower(), v) for k, v in scores.items() if isinstance(v, (int, float)) and v > 0),
        key=lambda kv: kv[1],
        reverse=True,
    )
    if not ranked:
        return "No clear pattern was found in the values."
    parts = [f"{friendly_type_name(k)} fit {_pct(v)} of the values" for k, v in ranked[:3]]
    return "Best matches: " + "; ".join(parts) + "."


def template_type_question(
    column_name: str,
    action: str,
    evidence: dict[str, Any],
    default: Optional[str] = None,
) -> RenderedDecisionText:
    """Plain-language question for an uncertain column type decision."""
    ev = evidence or {}
    trap = str(ev.get("unresolved_trap") or "")
    reasons: list[str] = []
    if trap == "ambiguous_date_format":
        reasons.append(
            "Some dates could be read day-first or month-first, so they cannot be "
            "interpreted without guessing."
        )
    elif trap.startswith("embedded_unit"):
        unit = ev.get("embedded_unit_detected")
        unit_txt = f" ({unit})" if unit else ""
        reasons.append(
            f"Values include units{unit_txt}; turning them into numbers would lose the units."
        )
    if ev.get("plus_sign_code_detected"):
        reasons.append(
            "Some values are a plus sign followed by many digits (like +447911123456), such as "
            "phone numbers; turning them into numbers would drop the plus sign."
        )
    if ev.get("leading_zero_detected") and action in ("cast_to_int", "cast_to_float"):
        reasons.append(
            "Some values start with zero (like 02138); turning them into numbers would drop the zeros."
        )
    if ev.get("decimal_comma_detected"):
        reasons.append("Numbers appear to use a comma as the decimal mark.")
    if not reasons and default is not None and default == action:
        reasons.append(
            "The reading itself is clear. This is flagged because some values look like "
            "placeholders for missing data (like '?' or -999); they will be treated as missing."
        )
    if not reasons:
        reasons.append(
            "The values fit more than one reading closely enough that a wrong guess could change them."
        )
    return RenderedDecisionText(
        summary=describe_type_scores(ev),
        question=f"How should column '{column_name}' be read?",
        explanation=" ".join(reasons),
    )


def render_question_text(decision: Decision) -> RenderedDecisionText:
    """
    Question phrasing for a decision that needs attention: `summary` holds the
    evidence in plain language, `question` the title, `explanation` the reason.
    """
    kind = decision.kind.lower().replace("-", "_")
    col_name = decision.columns[0] if decision.columns else "table"
    ev = decision.evidence or {}

    if kind in ("type_inference", "type_abstain", "type"):
        return template_type_question(col_name, decision.action, ev, decision.default)

    base = render_decision_text(decision)
    if kind in ("encoding", "text_format"):
        enc = decision.action[len("use_encoding_"):] if decision.action.startswith("use_encoding_") else None
        summary = f"The file looks like {friendly_text_format(enc)}."
        if ev.get("low_confidence") or (ev.get("confidence") or 1.0) < 0.80:
            summary += " The check was not certain about this."
    elif kind in ("dialect", "separator"):
        sep = decision.action[len("separate_by_"):] if decision.action.startswith("separate_by_") else ","
        summary = f"Columns appear to be split by {friendly_separator_name(sep)}."
        if ev.get("flagged") or (ev.get("confidence") or 1.0) < 0.80:
            summary += " Another separator fit almost as well."
    elif kind in ("header", "table_boundary"):
        summary = (
            "Row lengths vary across the file."
            if ev.get("is_ragged")
            else f"The column-names row was found with {_pct(ev.get('confidence'))} certainty."
        )
    elif kind in ("ambiguous_task", "task_inference", "task"):
        n = ev.get("num_unique")
        summary = f"The target column has {n} distinct values." if n is not None else base.summary
    else:
        summary = base.summary
    return RenderedDecisionText(
        summary=summary,
        question=base.question,
        explanation=base.explanation,
    )
