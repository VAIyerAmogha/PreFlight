"""
resolve(): turn a Plan's open questions into final answers.

Steps:
  1. Plan (from a Plan object, a data file, or a review.json written earlier).
  2. Collect every needs_attention Decision into ONE batched session.
  3. Apply stored answers whose fingerprint matches exactly (marked 'confirmed').
  4. Resolve what is left according to the mode (ask / defaults / strict).
  5. Persist new answers, then write plan.json and only then render the Plan PDF.
"""

from pathlib import Path
from typing import Any, Callable, Optional, Union

import pandas as pd

from preflight.decisions import Decision
from preflight.interact.channels.base import BaseChannel, ReviewPending
from preflight.interact.channels.callback import CallbackChannel
from preflight.interact.channels.notebook import NotebookChannel
from preflight.interact.channels.review_file import (
    ReviewFileChannel,
    load_review_file,
)
from preflight.interact.channels.terminal import TerminalChannel
from preflight.interact.modes import (
    apply_answer,
    apply_ask_mode,
    apply_defaults_mode,
    apply_strict_mode,
    in_notebook_kernel,
    resolve_mode,
)
from preflight.interact.question import Question, ReviewSession, create_review_session
from preflight.interact.store import AnswerStore
from preflight.plan import (
    ApplyContext,
    Plan,
    ReadingStage,
    default_out_dir,
    replan_prep,
    write_plan_artifacts,
)
from preflight.plan import (
    plan as make_plan,
)

ChannelArg = Union[str, BaseChannel, Callable[..., Any], None]


def _load_raw(plan_obj: Plan) -> Optional[pd.DataFrame]:
    """Raw values for previews. If the file cannot be re-read, previews say so."""
    try:
        return ReadingStage().apply(
            ApplyContext(source_path=Path(plan_obj.source_path)), plan_obj.decisions
        )
    except Exception:  # Swallowed: previews are optional; with None every preview says the values are unavailable
        return None




def _pick_channel(channel: ChannelArg, out_dir: Path, meta: dict[str, Any]) -> BaseChannel:
    if isinstance(channel, BaseChannel):
        return channel
    if channel is None:
        if in_notebook_kernel():
            try:
                import ipywidgets  # noqa: F401

                return NotebookChannel()
            except ImportError:  # Swallowed: no widgets installed, so fall back to the terminal prompt
                pass
        return TerminalChannel()
    if callable(channel):
        return CallbackChannel(channel)
    name = str(channel).lower()
    if name == "terminal":
        return TerminalChannel()
    if name == "notebook":
        return NotebookChannel()
    if name == "review_file":
        return ReviewFileChannel(out_dir / "review.json", meta=meta)
    raise ValueError(
        f"Unknown channel {channel!r}; use 'terminal', 'notebook', 'review_file', or a callable."
    )


def resolve(
    source_or_plan: Union[Plan, str, Path],
    mode: Optional[str] = None,
    channel: ChannelArg = None,
    out_dir: Optional[Union[str, Path]] = None,
    target: Optional[str] = None,
    task: Optional[str] = None,
) -> tuple[Plan, Path]:
    """
    Resolve every question in a Plan and write the final plan.json and Plan PDF.

    source_or_plan: a Plan (resolved in place), a data file, or the path of a review.json
        whose answers are filled in (mode is then 'ask' through the review file).
    mode: 'auto', 'ask', 'defaults' or 'strict'. 'auto' (or None) is ask in an
        interactive session (terminal or notebook kernel) and strict otherwise.
    channel: 'terminal', 'notebook', 'review_file', a Channel object, or a callable
        taking the list of Questions and returning {question_id: option}.
    out_dir: where plan.json, plan.pdf, answers.json and review.json go. Defaults to
        preflight_out/ in the current working directory; never the source file's own folder.

    Returns (Plan, path of the Plan PDF).
    Raises StrictResolutionError (strict), ReviewPending (answers not given yet; nothing
    is waited for), or ValueError subclasses naming the question for bad answers.
    """
    meta: dict[str, Any] = {}
    review_path: Optional[Path] = None

    if isinstance(source_or_plan, Plan):
        plan_obj = source_or_plan
        source = Path(plan_obj.source_path).resolve()
    else:
        p = Path(source_or_plan).resolve()
        if p.suffix.lower() == ".json" and p.exists():
            data = load_review_file(p)  # raises ReviewFileError if it is not a review file
            review_path = p
            source = Path(data["source_path"])
            target = target if target is not None else data.get("target")
            task = task if task is not None else data.get("task")
            if out_dir is None and data.get("out_dir"):
                out_dir = data["out_dir"]
            mode = mode or "ask"
            channel = channel if channel is not None else "review_file"
        else:
            source = p
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source}")
        plan_obj = make_plan(source, target=target, task=task)

    out_d = Path(out_dir).resolve() if out_dir is not None else default_out_dir()
    if out_d == source.parent:
        raise ValueError(
            f"out_dir must not be the source file's own folder ({out_d}); "
            "PreFlight never writes next to the source file."
        )
    out_d.mkdir(parents=True, exist_ok=True)

    ids = [d.id for d in plan_obj.decisions]
    if len(ids) != len(set(ids)):
        dupes = sorted({i for i in ids if ids.count(i) > 1})
        raise ValueError(f"Plan has duplicate decision ids, cannot resolve unambiguously: {dupes}")

    active_mode = resolve_mode(mode)
    meta = {"out_dir": str(out_d), "target": plan_obj.target_column, "task": plan_obj.task_type}
    store = AnswerStore(out_d)

    def _is_prep(d: Any) -> bool:
        return d.stage in ("clean", "engineer")

    def _pass(subset: list[Decision]) -> None:
        """Resolve the open questions among `subset` (stored answers first, in every mode)."""
        index = {d.id: d for d in plan_obj.decisions}
        session = create_review_session(
            subset,
            plan_obj.source_path,
            raw_df=_load_raw(plan_obj) if any(d.needs_attention for d in subset) else None,
            schema=plan_obj.schema,
        )
        remaining = []
        for q in session.questions:
            rec = store.lookup(q)
            if rec is None:
                remaining.append(q)
            else:
                apply_answer(index[q.decision_id], q, rec.answer, source="stored answer (same fingerprint)", reuse=True)
        session = ReviewSession(source_path=session.source_path, questions=remaining)

        if active_mode == "strict":
            apply_strict_mode(session)
        elif active_mode == "defaults":
            apply_defaults_mode(session, plan_obj.decisions)
        else:  # ask
            if session.questions:
                chan = _pick_channel(channel, out_d, meta)
                if review_path is not None and isinstance(chan, ReviewFileChannel):
                    chan.path = review_path
                answers = chan.review(session)  # validated: every question has one of its options
                statuses = apply_ask_mode(session, plan_obj.decisions, answers, source=f"ask: {chan.name} channel")
                for q in session.questions:
                    store.record(q, answers[q.question_id], statuses[q.question_id])
                store.save()

    if active_mode == "strict":
        # Strict resolves nothing new: it only reuses stored answers, in the same two passes
        # as the other modes (stored reading/typing answers can change what cleaning and
        # engineering propose), then lists every item still open.
        def _stored(subset: list[Decision]) -> list[Question]:
            index = {d.id: d for d in plan_obj.decisions}
            session = create_review_session(
                subset,
                plan_obj.source_path,
                raw_df=_load_raw(plan_obj) if any(d.needs_attention for d in subset) else None,
                schema=plan_obj.schema,
            )
            remaining = []
            for q in session.questions:
                rec = store.lookup(q)
                if rec is None:
                    remaining.append(q)
                else:
                    apply_answer(index[q.decision_id], q, rec.answer, source="stored answer (same fingerprint)", reuse=True)
            return remaining

        before_s = {d.id: d.action for d in plan_obj.decisions if not _is_prep(d)}
        open_items = _stored([d for d in plan_obj.decisions if not _is_prep(d)])
        if any(d.action != before_s[d.id] for d in plan_obj.decisions if not _is_prep(d)):
            replan_prep(plan_obj)
        open_items += _stored([d for d in plan_obj.decisions if _is_prep(d)])
        apply_strict_mode(ReviewSession(source_path=plan_obj.source_path, questions=open_items))
        plan_json, plan_pdf = write_plan_artifacts(plan_obj, out_d)
        return plan_obj, plan_pdf

    # Pass 1: reading and typing. Their answers decide what cleaning and engineering
    # propose, so those Decisions are planned again before they are asked about (pass 2).
    before = {d.id: d.action for d in plan_obj.decisions if not _is_prep(d)}
    _pass([d for d in plan_obj.decisions if not _is_prep(d)])
    if any(d.action != before[d.id] for d in plan_obj.decisions if not _is_prep(d)):
        replan_prep(plan_obj)
    _pass([d for d in plan_obj.decisions if _is_prep(d)])

    plan_json, plan_pdf = write_plan_artifacts(plan_obj, out_d)
    return plan_obj, plan_pdf


__all__ = ["resolve", "ReviewPending"]
